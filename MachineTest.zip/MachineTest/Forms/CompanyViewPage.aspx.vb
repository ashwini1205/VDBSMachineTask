﻿Imports System
Imports System.Configuration
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports SQLDataAccessLayer.DAL.DataCommunicator
Imports SQLDataAccessLayer.DAL.ComnCls
Imports SQLDataAccessLayer.DAL.BaseLayer

Partial Class Forms_CompanyViewPage
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            BindGrid()
        End If
    End Sub

    Private Sub BindGrid()
        Try
            Dim DB As New SQLDataAccessLayer.DAL.ComnCls
            Dim ds As New DataSet
            DB.AddParameter("@flg", 3)
            ds = DB.ExecuteDataSet(, "usp_CompanyDetails")
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    rptViewCompDetails.DataSource = ds
                    rptViewCompDetails.DataBind()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub


    Protected Sub rptViewCompDetails_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.RepeaterItemEventArgs) Handles rptViewCompDetails.ItemDataBound

    End Sub
End Class
