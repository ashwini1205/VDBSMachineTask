﻿Imports System
Imports System.Configuration
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports SQLDataAccessLayer.DAL.DataCommunicator
Imports SQLDataAccessLayer.DAL.ComnCls
Imports SQLDataAccessLayer.DAL.BaseLayer

Partial Class Forms_CompanyMaster
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            fileupd.Attributes.Add("multiple", "multiple")
           
        End If

    End Sub

    Protected Sub btnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSave.Click
        Try
            Dim DB As New SQLDataAccessLayer.DAL.ComnCls
            Dim DB1 As New SQLDataAccessLayer.DAL.ComnCls
            Dim icnt As Integer = 0
            Dim mxid As Integer = 0
            DB.AddParameter("@flg", 1)
            DB.AddParameter("@compname", txtCompane.Text)
            mxid = DB.ExecuteScalar(, "usp_CompanyDetails")
            If mxid > 0 Then
                For i As Integer = 0 To Request.Files.Count - 1
                    Dim fu As HttpPostedFile = Request.Files(i)

                    If fu.ContentLength > 0 Then

                        Dim fileName As String = Path.GetFileName(fu.FileName)
                        fu.SaveAs(Server.MapPath("~/upddocument/") & fileName)
                        DB1.AddParameter("@flg", 2)
                        DB1.AddParameter("@filnm", fileupd.FileName)
                        DB1.AddParameter("@compid", mxid)
                        icnt = DB1.ExecuteNonQuery(, "usp_CompanyDetails")

                    End If
                Next
                If icnt > 0 Then
                    lblSuccess.Visible = True
                    lblSuccess.Text = "Data Uploaded Successfully"

                Else
                    lblErrmsg.Visible = True
                    lblErrmsg.Text = "Error Occured"
                End If

            Else
                lblErrmsg.Visible = True
                lblErrmsg.Text = "Error Occured"
            End If


        Catch ex As Exception

        End Try
    End Sub
End Class
