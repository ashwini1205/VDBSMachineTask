﻿
//BEFORE USING THIS FILE, PLEASE CONFIRM FUNCTION'S OUTPUT.

// 1 . MAXLENGTH CHECKING FUNCTION  - NEED TO SEND CONTROL WITH ITS ID 
function CheckLength(controlvalue, length) {
    if (controlvalue.length > length) {
        return false;
    }
    return true;
}

// 2 .RESTIRCTED INPUTES CHECKING USING REGULAR EXPRESSION - key press event
function RegExpValidation(event) {
    event = event || window.event;
    var charCode = event.which || event.keyCode;
    var charStr = String.fromCharCode(charCode);
    if (event.key !== undefined && event.charCode === 0) {
        return;
    }
    if (/[\@\"\\\<\>\#\$\{\}\=}\/]+$/.test(charStr)) {
        return false;
    }
}
// 3 .SAVE PART VALIDATION CHECKING USING REGUALR EXPRESSION
function RestrictedValidation(controlvalue) {
    var regRV = /([<@#${}\\>"/])/;
    if (regRV.test(controlvalue)) {
        return false;
    }
}

// 4 . ALLOW INPUTES CHECKING USING REGUALR EXPRESSION - key press event
function AalphaValidation(event) {
    event = event || window.event;
    var charCode = event.which || event.keyCode;
    var charStr = String.fromCharCode(charCode);
    if (event.key !== undefined && event.charCode === 0) {
        return;
    }
    if (!/^[a-z A-Z\-\.\,\;\_\(\)]+$/.test(charStr)) {
        return false;
    }
}
// 5 . SAVE PART VALIDATION CHECKING USING REGUALR EXPRESSION
function AllowValidation(controlvalue) {
    if (!/^[a-z A-Z\-\.\,\;\_\(\)]+$/.test(controlvalue)) {
        return false;
    }
}

// 6.  ALLOW INPUTES NUMBERS CHECKING USING REGUALR EXPRESSION - key press event
function NumberValidationWithoutdot (event)
{
    event = event || window.event;
    var charCode = event.which || event.keyCode;
    var charStr = String.fromCharCode(charCode);
    if (event.key !== undefined && event.charCode === 0) {
        return;
    }
    if (!/^[0-9]+$/.test(charStr)) {
        return false;
    }
}
// 7 . SAVE PART VALIDATION CHECKING USING REGUALR EXPRESSION
function NumberValidation(controlvalue) {
    if (!/^[0-9]+$/.test(controlvalue)) {
        return false;
    }
}

//8 . ALLOW INPUTES NUMBERS CHECKING USING REGUALR EXPRESSION - key press event
function NumberValidationdot(event) {
    event = event || window.event;
    var charCode = event.which || event.keyCode;
    var charStr = String.fromCharCode(charCode);
    if (event.key !== undefined && event.charCode === 0) {
        return;
    }
    if (!/^[0-9\.]+$/.test(charStr)) {
        return false;
    }
   
}
//9. SAVE PART VALIDATION CHECKING USING REGUALR EXPRESSION
function NumberDotValidation(controlvalue) {
    if (!/^[0-9\.]+$/.test(controlvalue)) {
        return false;
    }
    if (controlvalue.split('.').length > 2) {
        return false;
    }
}

// 10 . SAVE PART VALIDATION CHECKING USING REGUALR EXPRESSION
function AllowAlphanumericValidation(controlvalue) {
    if (!/^[a-z A-Z 0-9\-\.\,\;\_\(\)]+$/.test(controlvalue)) {
        return false;
    }
}

function trim(string) {
    var a = string.replace(/^\s+/, '');
    return a.replace(/\s+$/, '')
}



function IsalphaNumericValidate(event) {
    
    event = event || window.event;
    var charCode = event.which || event.keyCode;
    var charStr = String.fromCharCode(charCode);
    if (event.key !== undefined && event.charCode === 0) {
        return;
    }
    if (!/^[a-zA-Z0-9-/]/.test(charStr)) {
        return false;
    }
}




