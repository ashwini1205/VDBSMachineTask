﻿
Partial Class MasterPage_MasterPage
    Inherits System.Web.UI.MasterPage
End Class

