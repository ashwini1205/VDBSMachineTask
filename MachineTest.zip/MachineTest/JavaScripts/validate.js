	function trim(str, chars) {
	    return ltrim(rtrim(str, chars), chars);
	}
	
	function ltrim(str, chars) {
	    chars = chars || "\\s";
	    return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
	}
	
	function rtrim(str, chars) {
	    chars = chars || "\\s";
	    return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
}


//Checks if the two dates are equal
function DateEqual(date1,date2)
{
	var i = ChangeFormat(date1);
	var f = ChangeFormat(date2);
	
	if(i == f)	
		 return true;	 
	else
		return false; 
}
	
function CheckEmail(name,str)
{
  var supported = 0;
  if (window.RegExp)
  {
    var tempStr = "a";
    var tempReg = new RegExp(tempStr);
    if (tempReg.test(tempStr)) supported = 1;
    
  }
  if (!supported)
    return (str.indexOf(".") > 2) && (str.indexOf("@") > 0);
  var r1 = new RegExp("(@.*@)|(\\.\\.)|(@\\.)|(^\\.)");
  var r2 = new 
  RegExp("^.+\\@(\\[?)[a-zA-Z0-9\\-\\.]+\\.([a-zA-Z]{2,3}|[0-9]{1,3})(\\]?)$");
  if(  (!r1.test(str) && r2.test(str)) == false)
  {
		alert("Please Enter a Valid Email Address");
		eval(name + ".select()");
		return false;					
  }
  else
	return true  
}


function CheckText(displayname,name,str,flag)		
{
	
	Retval=1
	e = new String(str)
	if(flag==1)
	{
		for(i=0 ;i<e.length ;i++)
		{	
			if(e.charAt(i) == '<')
			{
				chr=e.charAt(i)
				Retval = 0
				break;
			}	
			else if(e.charAt(i) == '>')
			{
				chr = e.charAt(i)
				Retval = 0
				break;
			}				
		}				
	}
	if(Retval == 0) 
	{
		alert("Invalid character '" + chr + "' in the '"+ displayname+"'")
		eval(name + ".focus()");
		return false;
	}
	
	
	if(str.length == "" || isNaN(str.length))
	{
		alert(displayname + " cannot be blank.");
		eval(name + ".focus()");		
		return false;
		
	}
	
	else if(isNaN(str)==0)
	{
		alert(displayname + " is invalid");
		eval(name + ".select()");		
		eval(name + ".focus()");		
		return false;
	}		
	
}


function CheckNumber(displayname,name,num)		
{
	
	if(num.length == "" || isNaN(num.length))
	{

		alert(displayname + " cannot be blank.");
		eval(name + ".focus()");		
		return false;
		
	}	
	
	else if(isNaN(num))
	{
		alert(displayname + " is invalid");
		eval(name + ".select()");		
		eval(name + ".focus()");		
		return false;
		
	}		

}

//This function converts a dates like 2/2/2000 to 02/02/2000 
function ChangeFormat(datefield)
{
   var s = datefield;
   var j = s.split("/");
   var dd = Number(j[0]);
   var mm = Number(j[1]);
   var yy = Number(j[2]);
   var mystr;
   if (dd<10 && mm<10)
    mystr = "0" + dd + "/0" + mm + "/" + yy;
   else if (mm<10)
    mystr = dd + "/0" + mm + "/" + yy;
   else if (dd < 10)
    /*mystr = "0" + dd + "/0" + mm + "/" + yy; */
    /* New Modifed Code Below*/
    mystr = "0" + dd + "/" + mm + "/" + yy; 
   else
    mystr = s; 
   return mystr;   
} 

//This function checks the format of date dd/mm/yyyy
function IsCorrectFormat(datefield)
 {
   var strLen,len , flag ;
   flag = 0 ;
   
   strLen = new String(datefield) ;
   len = strLen.length ;
  
  if(len > 10)
   {	
    flag+=1;
   }
  else
  { 
  var s = datefield;
  var j = s.split("/");
  if (isNaN(j[0]))
   flag+= 1;
  if (isNaN(j[1]))
   flag+= 1;
  if (isNaN(j[2]))
     flag+= 1;
  else
    {
       if( j[2].length < 4)  
       flag+=1;
    }
     
  }   
  if(flag!=0) 
    return false;
  else 
    return true;
 }
 //This Function Checks Whether Valid Date is entered or not.
 function ValidDate(datefield)
 {
   var s = datefield;
   var myF = 0;
   if(datefield == "")
    myF+=1;
   else
   {
    if(!IsCorrectFormat(datefield)) //if invalid date then 
	  myF+=1;
	else //correct date format, check if this is a valid date ??
	 {
	   var j = s.split("/");
	   var dd = Number(j[0]);
		var mm = Number(j[1]);
		var yy = Number(j[2]);
		var NFlag  = "0";		
		
		if(mm>12 || dd > 31 || dd < 1 || mm < 1)
		{
		 myF+=1;
		} 
		else 
		 if (mm==1 || mm==3 || mm==5 || mm==7 || mm==8 || mm==10 || mm==12)
		 {
		     if(dd > 31)
		         myF+=1;
		 }
		 else if (mm==4 || mm==6 || mm==9 || mm==11)
		 {
		    if(dd > 30)
		 	    myF+=1;
		 }
		 else if (mm==2)
		 {
		   	/*if(dd>=29)
		   		  myF+=1;
		 	  else if (yy % 4 == 0 && dd >= 29)
		         myF+=1; 
		     */
		     
		    /* New Modifed Code Below*/
			var isleap = (yy % 4 == 0 && (yy % 100 != 0 || yy % 400 == 0))			
			if (dd>29 || (dd==29 && !isleap))
				myF+=1;				  
				 
		 }
		 if (yy > 9999 || yy <= 1800)
		 {
		    myF+=1;
		 }
	}
  }	 
  if(myF==0)
   return true;
  else
   return false; 
 } 
function Check(mydate)
{
 if (ValidDate(mydate.value)==false)
 {
  alert("Please Enter Valid Date..");
  mydate.focus();
 }
}

/*function Validate()
{
date1 = document.form1.date1.value;
date2 = document.form1.date2.value; 
if(ValidDate(ChangeFormat(date1))==false)
{
 alert("Invalid Start Date..");
 document.form1.date1.focus();
 return false;
}
if(ValidDate(ChangeFormat(date2))==false)
{
 alert("Invalid End Date..");
 document.form1.date2.focus();
 return false;
}
if(Compare(ChangeFormat(date1),ChangeFormat(date2))==false)
{
alert("Do Not Match..");
document.form1.date1.focus();
return false;
}
}*/


function Compare(date1,date2)
{
	var i = ChangeFormat(date1);
	var f = ChangeFormat(date2);
	var issdt = new Date(i.substring(6,10),Number(i.substring(3,5))-1,i.substring(0,2));
	var findt = new Date(f.substring(6,10),Number(f.substring(3,5))-1,f.substring(0,2));
//	alert(issdt);
//	alert(findt);
		if(issdt > findt)
			return false;
	//	else if (issdt == findt)
	//	    return false;
		else    
	        return true; 
}

function Comparedt(date1,date2)
{
	var i = ChangeFormat(date1);
	var f = ChangeFormat(date2);
	var issdt = new Date(i.substring(6,10),Number(i.substring(3,5))-1,i.substring(0,2));
	var findt = new Date(f.substring(6,10),Number(f.substring(3,5))-1,f.substring(0,2));
	//alert(issdt);
	//alert(findt);
		if(issdt >= findt)
			return false;
	//	else if (issdt == findt)
	//	    return false;
		else    
	        return true; 
}
function Comparedt1(date1,date2)
{
	var i = ChangeFormat(date1);
	var f = ChangeFormat(date2);
	var issdt = new Date(i.substring(6,10),Number(i.substring(3,5))-1,i.substring(0,2));
	var findt = new Date(f.substring(6,10),Number(f.substring(3,5))-1,f.substring(0,2));
	//alert(issdt);
	//alert(findt);
		if(issdt > findt)
			return false;
	//	else if (issdt == findt)
	//	    return false;
		else    
	        return true; 
}

//Function to compare today's date with some other date..
function CompareToday(date)
{

var f = ChangeFormat(date);
var findt = new Date(f.substring(6,10),Number(f.substring(3,5))-1,f.substring(0,2));
var issdt = new Date();
//alert("comparet"+ issdt)
//alert("comparet"+ findt)
if(issdt >= findt)
 return false;
else
 return true; 
}

function CompareToday1(date)
{

var f = ChangeFormat(date);
var findt = new Date(f.substring(6,10),Number(f.substring(3,5))-1,f.substring(0,2));
var issdt = new Date();
//alert("comparet"+ issdt)
//alert("comparet"+ findt)
if(issdt <= findt)
 return false;
else
 return true; 
}

 
function CheckFYyear(cdate)
{
	var dt = new Date();
	yr1 = dt.getFullYear()
	yr2 = dt.getFullYear() + 1
	
	yr = cdate.split("/");
	if(yr[2] < yr1 || yr[2] > yr2)		
		return false;	
	else
		return true;			

} 

//this function will be used to trim - same will be used for checking spaces as well...
function trimString (str) {
  while (str.charAt(0) == ' ')
    str = str.substring(1);
  while (str.charAt(str.length - 1) == ' ')
    str = str.substring(0, str.length - 1);
  return str;
 }

 function round_decimals(original_number, decimals)
{
	var result1 = original_number * Math.pow(10, decimals)
	var result2 = Math.round(result1)
	var result3 = result2 / Math.pow(10, decimals)
	return pad_with_zeros(result3, decimals)
}

function round_lower(original_number, decimals)
{
	var result1,result2,result3,ind;
	//alert("Hi " + original_number)
	ind = original_number.toString().indexOf('.');
	//alert(ind)
	if(ind < 0)
	{
		result2 = original_number
	}
	else
	{
		result1 = original_number.toString().split(".");
		if(trimString(result1[0]) == "" || Number(result1[0]) <= 0)
			result2 = 0
		else
			result2 = result1[0];
	}
	result3 = result2
	//alert(result2);
	return pad_with_zeros(result3,decimals)
}

function pad_with_zeros(rounded_value, decimal_places)
{
	// Convert the number to a string
	var value_string = rounded_value.toString()
	// Locate the decimal point
	var decimal_location = value_string.indexOf(".")
	// Is there a decimal point?
	if (decimal_location == -1)
	{

		// If no, then all decimal places will be padded with 0s
		decimal_part_length = 0

		// If decimal_places is greater than zero, tack on a decimal point
		value_string += decimal_places > 0 ? "." : ""

	}
	else
	{
		// If yes, then only the extra decimal places will be padded with 0s
		decimal_part_length = value_string.length - decimal_location - 1
	}

	// Calculate the number of decimal places that need to be padded with 0s
	var pad_total = decimal_places - decimal_part_length

	if (pad_total > 0)
	{
		// Pad the string with 0s
		for (var counter = 1; counter <= pad_total; counter++) 
		value_string += "0"
	}
	return value_string
}


function ValidateString(fieldnm)
{
	 ///To check that only characters and numbers are present in string entered
	var compstr
	var temp
	var vstr
	var field
	vstr="valid"
	field=fieldnm
	compstr="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890 "

	for (i=0;i<=field.value.length;i++)
	{
	  temp="" + field.value.substring(i,i+1);

	  if (compstr.indexOf(temp) == "-1") vstr = "invalid";
	}  
	 if (vstr=="invalid")
	 {
	  alert("Invalid entry,only characters or numbers are allowed.");
	  field.focus();
	  return false; 
	 }
	 return true;
} 



function IsValidTime(timeStr) 
{
	// Checks if time is in HH:MM:SS AM/PM format.
	var Err=0;
	var timePat = /^(\d{1,2}):(\d{2})(:(\d{2}))?(\s?( AM| am| PM| pm))?$/;
	var matchArray = timeStr.match(timePat);
	if (matchArray == null) 
	{
		alert("Time is not in a valid format.");
		Err++;
		return false;
	}
	hour = matchArray[1];
	minute = matchArray[2];
	second = matchArray[4];
	ampm = matchArray[6];

	if (second=="") { second = null; }
	if (ampm=="") { ampm = null }
	if (hour < 0  || hour > 23) 
	{
		alert("Hour must be between 1 and 12. (or 0 and 23 for military time)");
		Err++;
	}
	if (ampm == null) 
	{
		alert("You must specify AM or PM.");
		Err++;
	}
	if (minute<0 || minute > 59) 
	{
		alert ("Minute must be between 0 and 59.");
		Err++;
	}
	if (second != null && (second < 0 || second > 59)) 
	{
		alert ("Second must be between 0 and 59.");
		Err++;
	}
	if(Err==0)
		return true;
	else
		return false;
}

function roundNum(num)
{
  var result1,result2,result3 ;
  
  result1 = num * Math.pow(10,2) ;
  result2 = Math.round(result1) ;
  result3 = result2 / Math.pow(10,2) ;
   
  return result3 ;
}

function GetDayDiff(fromdt,todt)
 {
 
   var fdt,tdt,ftemp,ttemp,diff,days,timediff,arrfdt,arrtdt
   diff=new Date();
   
   fdt=new String(fromdt)
   arrfdt=fdt.split('/') 
   fdt=arrfdt[1]+"/"+arrfdt[0]+"/"+arrfdt[2]   
      
   tdt=new String(todt)
   arrtdt=tdt.split('/')
   tdt=arrtdt[1]+"/"+arrtdt[0]+"/"+arrtdt[2]     
  
   ftemp=new Date(fdt)
   ttemp=new Date(tdt) 
    
   diff.setTime(Math.abs(ftemp.getTime() - ttemp.getTime()));
  
   timediff = diff.getTime();
  
   days = Math.floor(timediff / (1000 * 60 * 60 * 24));
   return Number(days);      
 }
 
 
 function display(viewShow)
{
	
	if(document.layers)
	{
		content = document.layers[viewShow];

	} else if (document.all)

	{

		content = document.all(viewShow).style;

	}
     content.visibility = 'visible';

}


function hide(viewHide)
{

	if (document.layers)
	{
	
		content = document.layers[viewHide];

	} else if (document.all)

	{

		content = document.all(viewHide).style;

	}
     content.visibility = 'hidden';

}


function GetDateDiff(fromdt,todt)
 {
   var fdt,tdt,ftemp,ttemp,diff,days,months,timediff,arrfdt,arrtdt
   diff=new Date();
   
   fdt=new String(fromdt)
   arrfdt=fdt.split('/') 
   fdt=arrfdt[1]+"/"+arrfdt[0]+"/"+arrfdt[2]   
      
   tdt=new String(todt)
   arrtdt=tdt.split('/')
   tdt=arrtdt[1]+"/"+arrtdt[0]+"/"+arrtdt[2]     
  
   ftemp=new Date(fdt)
   ttemp=new Date(tdt) 
    
   diff.setTime(Math.abs(ftemp.getTime() - ttemp.getTime()));
  
   timediff = diff.getTime();
  
   months = Math.floor(timediff / (1000 * 60 * 60 * 24 * 30));
  
   return Number(months);      
 }

function roundNumToDecimals(original_number, decimals)
{
	var result1 = original_number * Math.pow(10, decimals)
	var result2 = Math.round(result1)
	var result3 = result2 / Math.pow(10, decimals)
	return pad_with_zeros(result3, decimals)
}
//sonali
function IsAlpha(str)
{
	var strString = str;
    var strValidChars = "abcdefghijklmnopqrstuvwzyxABCDEFGHIJKLMNOPQRSTUVWZYX.& ";
    var strChar;
    var blnResult = true;
    if (strString.length == 0) return false;
    //  test strString consists of valid characters listed above
    for (i = 0; i < strString.length && blnResult == true; i++)
	{
		strChar = strString.charAt(i);
        if (strValidChars.indexOf(strChar) == -1)
        {
			blnResult = false;
        }//if
	}//for
    if( blnResult == false)
    {
		//alert("Please enter alphabets only")
		return false;
    }//if
 }//fn IsAlpha

//mohini-06/10/2006
function ValidatePhone(str)
{


	var strString = str;
    var strValidChars = "1234567890- ";
    var strChar;
    var blnResult = true;
    if (strString.length == 0) 
    return false;
    //  test strString consists of valid characters listed above
    for (i = 0; i < strString.length && blnResult == true; i++)
	{
			strChar = strString.charAt(i);
        if (strValidChars.indexOf(strChar) == -1)
        {
			blnResult = false;
        }//if
	}//for
    if(blnResult == false)
    {
		return false;
		
    }//if
    
return true;
     
 }//fn ValidatePhone

 function EnterMouse(obj) {

     if (obj != null) {

         obj.style.borderBottomColor = "#980000"
         obj.style.borderTopColor = "#980000"
         obj.style.borderLeftColor = "#980000"
         obj.style.borderRightColor = "#980000"              
     }
 }
 function LeaveMouse(obj1)
  {
     if (obj1 != null) {

         obj1.style.borderBottomColor = "#9999cc"
         obj1.style.borderTopColor = "#9999cc"
         obj1.style.borderLeftColor = "#9999cc"
         obj1.style.borderRightColor = "#9999cc"
     }
 }
 
 
 function trim(str, chars) {
      return ltrim(rtrim(str, chars), chars);
  }
 
  function ltrim(str, chars) {
      chars = chars || "\\s";
      return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
  }
 
  function rtrim(str, chars) {
      chars = chars || "\\s";
      return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
 }
 function GetMonthValue(PassMonth) {
 
      var iMon = 0
 
      switch (PassMonth) {
          case "Jan": iMon = 1; return iMon; break;
          case "Feb": iMon = 2; return iMon; break;
          case "Mar": iMon = 3; return iMon; break;
          case "Apr": iMon = 4; return iMon; break;
          case "May": iMon = 5; return iMon; break;
          case "Jun": iMon = 6; return iMon; break;
          case "Jul": iMon = 7; return iMon; break;
          case "Aug": iMon = 8; return iMon; break;
          case "Sep": iMon = 9; return iMon; break;
          case "Oct": iMon = 10; return iMon; break;
          case "Nov": iMon = 11; return iMon; break;
          case "Dec": iMon = 12; return iMon; break;
 
      }
  }




  // This javascript functions are used for ajax city dropdown


  var xmlHttp;
  var DivTagID;
  var SCTextID;

  function CloseWindow(DivID) {
    //  alert('test');
      document.getElementById(DivID).style.visibility = "hidden";
    
  }

  function maskcharPress(objEvent) {
      var iKeyCode, strKey;
      var reValidChars = /^[a-z A-Z]/;
      iKeyCode = objEvent.keyCode;
      strKey = String.fromCharCode(iKeyCode);
      if (!reValidChars.test(strKey)) {
          return false;
      }
  }



  function stateChanged() {
      var pendingImg, strFinalString, b;
      var strResponse = new String();
    
      if (xmlHttp.readyState == 4 || xmlHttp.readyState == "complete") {
          if (xmlHttp.responseText != "") {

              strResponse = xmlHttp.responseText;

              strFinalString = strResponse.substring(0, strResponse.indexOf("</table></td></tr></table>")) + "</table></td></tr></table>";

              document.getElementById(DivTagID).innerHTML = strFinalString; //xmlHttp.responseText;
          }
          else
              document.getElementById(DivTagID).innerHTML = "<center><img src='../../App_Themes/Images/Working.gif'></center>";

          SetDivPosition(DivTagID, SCTextID);
          document.getElementById(DivTagID).style.visibility = "visible";
      }
      else {
          document.getElementById(DivTagID).innerHTML = "<center><img src='../../App_Themes/Images/Working.gif'></center>";
          SetDivPosition(DivTagID, SCTextID);
          document.getElementById(DivTagID).style.visibility = "visible";
      }
  }

  function GetXmlHttpObject(handler) {
      var objXmlHttp = null;
      if (navigator.userAgent.indexOf("Opera") >= 0) {
          alert("This example doesn't work in Opera");
          return
      }
      if (navigator.userAgent.indexOf("MSIE") >= 0) {
          var strName = "Msxml2.XMLHTTP";
          if (navigator.appVersion.indexOf("MSIE 5.5") >= 0) {
              strName = "Microsoft.XMLHTTP";
          }
          try {
              objXmlHttp = new ActiveXObject(strName);
              objXmlHttp.onreadystatechange = handler;
              return objXmlHttp;
          }
          catch (e) {
              alert("Error. Scripting for ActiveX might be disabled");
              return
          }
      }
      if (navigator.userAgent.indexOf("Mozilla") >= 0) {
          objXmlHttp = new XMLHttpRequest();
          objXmlHttp.onload = handler;
          objXmlHttp.onerror = handler;
          return objXmlHttp;
      }
  }


  function showHint(MastName, str, DivID, CodeID, TextID, ID, TextField, Tablename, Condition) {
   
      DivTagID = DivID;
      SCTextID = TextID;
       if (str.length > 0) {
          if (MastName == "City") {
              var url = "../../AjaxDropDown/City.aspx?strVal=" + str + "&DivID=" + DivID + "&CodeID=" + CodeID + "&TextID=" + TextID + "&ID=" + ID + "&TextField=" + TextField +"&Tablename=" + Tablename  + "&Condition=" + Condition 
          }

          xmlHttp = GetXmlHttpObject(stateChanged)

          xmlHttp.open("GET", url, true)
          xmlHttp.send(null)
          document.getElementById(DivID).innerHTML = "";
       
      }
      else {
         // alert('dts');
          document.getElementById(DivID).innerHTML = "";
         document.getElementById(DivID).style.visibility = "hidden";
        //  document.getElementById(DivID).style.display = "none";
      }
  }

  function hideDivTag(TextID, DivID) {
  
     
      
      if (document.getElementById("ctl00_ContentPlaceHolder1_" + TextID).value == 'Type text to search nationality.') {
          document.getElementById("ctl00_ContentPlaceHolder1_" + TextID).innerText = '';
      }
     if (document.getElementById("ctl00_ContentPlaceHolder1_" + TextID).value == 'Type text to search city.') {
          document.getElementById("ctl00_ContentPlaceHolder1_" + TextID).innerText = '';
      }
     
      document.getElementById(DivID).style.visibility = "hidden";
  }


  var DivTagID, FromFlag, GCount;
 function FillData(Code, Name, CodeID, TextID, DivID) {

      document.getElementById("ctl00_ContentPlaceHolder1_" + TextID).value = Name;
      document.getElementById("ctl00_ContentPlaceHolder1_" + CodeID).value = Code;
      CloseWindow(DivID);
   
  }
   function SetDivPosition(DTagID, TextID) {
      var tDiv, TText, PosX, PosY;
      tDiv = eval('document.getElementById("' + DTagID + '")');

      TText = eval('document.getElementById("ctl00_ContentPlaceHolder1_' + TextID + '")');

      PosX = findPosX(TText);
      PosY = findPosY(TText);
      tDiv.style.left = PosX;
      tDiv.style.top = PosY;
  }

  function findPosX(obj) {
      var curleft = 0;
      if (obj.offsetParent) {
          while (obj.offsetParent) {
              curleft += obj.offsetLeft;
              obj = obj.offsetParent;
          }
      }
      else if (obj.x)
          curleft += obj.x;
      return curleft;
  }

  function findPosY(obj) {
      var curtop = 0;
      if (obj.offsetParent) {
          curtop += obj.offsetHeight;
          while (obj.offsetParent) {
              curtop += obj.offsetTop;
              obj = obj.offsetParent;
          }
      }
      else if (obj.y) {
          curtop += obj.y;
          curtop += obj.height;
      }
      return curtop;
  }

  function TextClear(TextID) {

      if (document.getElementById("ctl00_ContentPlaceHolder1_" + TextID).value == "Type text to search city.") {

          document.getElementById("ctl00_ContentPlaceHolder1_" + TextID).value ="";
          
      }
  }
  


function InsertZeroZero(obj) {

      if (obj != null) {

          if (obj.value.length > 0) {
              var temp = obj.value;

              if (obj.value.length > 2) {
                  var myvar = obj.value.indexOf(".");
                  if (parseFloat(obj.value.charAt(myvar + 1)) != 5 && obj.value.length == 3 && myvar > 0) {
                      alert('Invalid value for days.');
                      obj.focus();
                      return false;
                  }
                  else {
                      if (parseFloat(obj.value.charAt(myvar + 1)) == 5 && obj.value.length > 3 && myvar > 0) {
                          if ((parseFloat(obj.value.charAt(myvar + 2)) != 5 || parseFloat(obj.value.charAt(myvar + 2)) == 5) && (myvar == 1)) {
                              alert('Invalid value for days.');
                              obj.focus();
                              return false;
                          }
                          if (parseFloat(obj.value.charAt(myvar + 2)) == 5 && obj.value.length > 4 && myvar > 0) {
                              if ((parseFloat(obj.value.charAt(myvar + 3)) != 5 || parseFloat(obj.value.charAt(myvar + 3)) == 5) && (myvar == 1)) {
                                  alert('Invalid value for days.');
                                  obj.focus();
                                  return false;
                              }

                          }
                          else {
                              if (parseFloat(obj.value.charAt(myvar + 2)) != 5 && obj.value.length > 4 && myvar > 0) {
                              }
                          }
                      }
                      else {
                          if (myvar == 0 && obj.value.length == 3 && parseFloat(obj.value.charAt(myvar + 1)) != 5) {
                              alert('Invalid value for days.');
                              obj.focus();
                              return false;
                          }
                          else {
                              if (myvar == 0 && obj.value.length == 3 && parseFloat(obj.value.charAt(myvar + 1)) == 5) {
                                  if (parseFloat(obj.value.charAt(myvar + 2)) != 5 || parseFloat(obj.value.charAt(myvar + 2)) == 5) {
                                      alert('Invalid value for days.');
                                      obj.focus();
                                      return false;
                                  }
                              }
                          }
                          if (myvar == 0 && obj.value.length == 4) {
                              //&& parseFloat(obj.value.charAt(myvar + 1)) != 5) {
                              if (parseFloat(obj.value.charAt(myvar + 1)) != 5) {
                                  alert('Invalid value for days.');
                                  obj.focus();
                                  return false;
                              }
                              if (parseFloat(obj.value.charAt(myvar + 1)) == 5) {
                                  if (parseFloat(obj.value.charAt(myvar + 2)) == 5 || parseFloat(obj.value.charAt(myvar + 2)) != 5) {
                                      alert('Invalid value for days.');
                                      obj.focus();
                                      return false;
                                  }
                                  if (parseFloat(obj.value.charAt(myvar + 3)) == 5 || parseFloat(obj.value.charAt(myvar + 3)) != 5) {
                                      alert('Invalid value for days.');
                                      obj.focus();
                                      return false;
                                  }
                              }
                          }
                          if (myvar == 0 && obj.value.length == 5) {
                              //&& parseFloat(obj.value.charAt(myvar + 1)) != 5) {
                              if (parseFloat(obj.value.charAt(myvar + 1)) != 5) {
                                  alert('Invalid value for days.');
                                  obj.focus();
                                  return false;
                              }
                              if (parseFloat(obj.value.charAt(myvar + 1)) == 5) {
                                  if (parseFloat(obj.value.charAt(myvar + 2)) == 5 || parseFloat(obj.value.charAt(myvar + 2)) != 5) {
                                      alert('Invalid value for days.');
                                      obj.focus();
                                      return false;
                                  }
                                  if (parseFloat(obj.value.charAt(myvar + 3)) == 5 || parseFloat(obj.value.charAt(myvar + 3)) != 5) {
                                      alert('Invalid value for days.');
                                      obj.focus();
                                      return false;
                                  }
                                  if (parseFloat(obj.value.charAt(myvar + 4)) == 5 || parseFloat(obj.value.charAt(myvar + 4)) != 5) {
                                      alert('Invalid value for days.');
                                      obj.focus();
                                      return false;
                                  }
                              }
                          }
                      }
                  }
                  //return false;
                  if (myvar == 2) {
                      if (parseFloat(obj.value.charAt(myvar + 1)) != 5 && obj.value.length == 4) {
                          alert('Invalid value for days.');
                          obj.focus();
                          return false;
                      }
                      if (parseFloat(obj.value.charAt(myvar + 1)) == 5 && obj.value.length > 4) {
                          alert('Invalid value for days.');
                          obj.focus();
                          return false;
                      }
                  }
                  if (myvar == 3) {
                      if (parseFloat(obj.value.charAt(myvar + 1)) != 5 && obj.value.length == 5) {
                          alert('Invalid value for days.');
                          obj.focus();
                          return false;
                      }

                  }
                  if (myvar == 1) {
                      if (parseFloat(obj.value.charAt(myvar + 1)) != 5 && obj.value.length >= 4) {
                          alert('Invalid value for days.');
                          obj.focus();
                          return false;
                      }
                  }
              }
              else {
                  if (obj.value.length <= 2) {
                      var stext = obj.value.toString().split(".")
                      if (stext.length == 1) {
                          obj.value = obj.value; return false;
                      }
                      else {
                          if (stext.length == 2) {
                              var myvar = obj.value.indexOf(".");
                              if (obj.value.charAt(myvar) == ".") {
                                  if (myvar == 0 && parseFloat(obj.value.charAt(myvar + 1)) != 5) {
                                      alert('Invalid value for days.');
                                      obj.focus();
                                      return false;
                                  }
                                  else {
                                      if (myvar == 0 && parseFloat(obj.value.charAt(myvar + 1)) == 5) {
                                          obj.value = myvar + '.'+ obj.value.charAt(myvar + 1);
                                          return false;
                                      }
                                  }
                                  if (myvar == 1 && obj.value.length == 2) {
                                      alert('Invalid value for days.');
                                      obj.focus();
                                      return false;
                                  }
                               
                                 
                              }
                          }
                      }
                  }                                           
              }
          }
      }

  }

  //This function converts a dates like 2/2/2000 to 02/02/2000
  function ChangeDateFormat(datefield)//dd/mm/yy
  {
      var s = datefield;
      var j = s.split("-");
      var dd = Number(j[0]);
      var mmm = j[1];
      var mm;
      var yy = Number(j[2]);
      var mystr;

      if (mmm == 'Jan')
          mm = 01
      else if (mmm == 'Feb')
          mm = 02
      else if (mmm == 'Mar')
          mm = 03
      else if (mmm == 'Apr')
          mm = 04
      else if (mmm == 'May')
          mm = 05
      else if (mmm == 'Jun')
          mm = 06
      else if (mmm == 'Jul')
          mm = 07
      else if (mmm == 'Aug')
          mm = 08
      else if (mmm == 'Sep')
          mm = 09
      else if (mmm == 'Oct')
          mm = 10
      else if (mmm == 'Nov')
          mm = 11
      else if (mmm == 'Dec')
          mm = 12

      if (dd < 10 && mm < 10) {
          //alert("1");
          mystr = "0" + dd + "/0" + mm + "/" + yy;
      }
      else if (mm < 10) {//alert("2");
          mystr = dd + "/0" + mm + "/" + yy;
      }
      else if (dd < 10) {
          //alert("3");
          /*mystr = "0" + dd + "/0" + mm + "/" + yy; */
          /* New Modifed Code Below*/
          mystr = "0" + dd + "/" + mm + "/" + yy;
      }
      else if (dd > 10) {
          mystr = dd + "/" + mm + "/" + yy;
      }
      else
          mystr = s;
      return mystr;
  }
  //Added by chandrakant on 18 August 2012
  function CheckExtension(File,type) {
      var Extension = File.substring(File.lastIndexOf('.') + 1).toLowerCase();
      if (type == "CV") {
          if (Extension == "pdf" || Extension == "doc" || Extension == "docx") {
              return true;
          }
          else {
              alert('Please Upload .pdf/.doc/.docx for CV.');
              return false;
          }
      }
     if (type == "FS") {
              if (Extension == "xlsx" || Extension == "doc" || Extension == "docx" || Extension == "xls" || Extension == "pdf") {
                  return true;
              }
              else {
                  alert('Please Upload .xls/.xlsx/.doc/.docx/.pdf for Fitment Sheet.');
                  return false;
              }
         }
     if (type == "PPS") {
          if (Extension == "jpg" || Extension == "doc" || Extension == "docx" || Extension == "pdf") {
                  return true;
              }
              else {
                  alert('Please Upload .jpg/.doc/.docx/.pdf for Pervious Pay Slip.');
                  return false;
              }
      }
       
         if (type == "AS") {
              if (Extension == "pdf") {
                  return true;
              }
              else {
                  alert('Please Upload .pdf for Assessment Sheet.');
                  return false;
              }
        }
         if (type == "PHRC") {
              if (Extension == "pdf") {
                  return true;
              }
              else {
                  alert('Please Upload .pdf for Pre-Hire Ref Check Report.');
                  return false;
              }
         }
        if (type == "AN") {
            if (Extension == "jpg" || Extension == "pdf" || Extension == "doc" || Extension == "xls" || Extension == "txt" || Extension == "docx" || Extension == "xlsx") {             
                 return true;
             }
             else {
                 alert('Please Upload .pdf/.jpg/.doc/.docx/.xls/.xlsx/.txt for Approval Note');
                 return false;
             }
         }
          
      if (type == "OD") {
          if (Extension == "jpg" || Extension == "pdf" || Extension == "doc" || Extension == "xls" || Extension == "txt" || Extension == "docx" || Extension == "xlsx") {

                  return true;
              }
              else {
                  alert('Please Upload .pdf/.jpg/.doc/.docx/.xls/.xlsx/.txt for Other Document');
                  return false;
              }
       }
   }
//Added by Chandrakant to show TCC Amt in Words
   function NumberToWords(tccamt) {
      
       var junkVal = tccamt

       junkVal = Math.floor(junkVal);

       var obStr = new String(junkVal);

       numReversed = obStr.split("");

       actnumber = numReversed.reverse();



       if (Number(junkVal) >= 0) {

           //do nothing  

       }

       else {

           alert('wrong Number cannot be converted');

           return false;

       }
       
       if (Number(junkVal) == 0) {
          
           //document.getElementById('container').innerHTML = obStr + '' + 'Rupees Zero Only';

           return 0;

       }

       if (actnumber.length > 9) {

           alert('Oops!!!! the Number is too big to covertes');

           return false;

       }



       var iWords = ["Zero", " One", " Two", " Three", " Four", " Five", " Six", " Seven", " Eight", " Nine"];

       var ePlace = [' Ten', ' Eleven', ' Twelve', ' Thirteen', ' Fourteen', ' Fifteen', ' Sixteen', ' Seventeen', ' Eighteen', ' Nineteen'];

       var tensPlace = ['dummy', ' Ten', ' Twenty', ' Thirty', ' Forty', ' Fifty', ' Sixty', ' Seventy', ' Eighty', ' Ninety'];



       var iWordsLength = numReversed.length;

       var totalWords = "";

       var inWords = new Array();

       var finalWord = "";

       j = 0;

       for (i = 0; i < iWordsLength; i++) {

           switch (i) {

               case 0:

                   if (actnumber[i] == 0 || actnumber[i + 1] == 1) {

                       inWords[j] = '';
                   }

                   else {

                       inWords[j] = iWords[actnumber[i]];

                   }

                   inWords[j] = inWords[j] + ' Only';

                   break;

               case 1:

                   tens_complication();

                   break;

               case 2:

                   if (actnumber[i] == 0) {

                       inWords[j] = '';

                   }
                   else if (actnumber[i - 1] != 0 && actnumber[i - 2] != 0) {

                       inWords[j] = iWords[actnumber[i]] + ' Hundred and';

                   }

                   else {

                       inWords[j] = iWords[actnumber[i]] + ' Hundred';

                   }

                   break;

               case 3:

                   if (actnumber[i] == 0 || actnumber[i + 1] == 1) {

                       inWords[j] = '';

                   }

                   else {

                       inWords[j] = iWords[actnumber[i]];

                   }

                   if (actnumber[i + 1] != 0 || actnumber[i] > 0) {

                       inWords[j] = inWords[j] + " Thousand";
                   }

                   break;

               case 4:

                   tens_complication();

                   break;

               case 5:

                   if (actnumber[i] == 0 || actnumber[i + 1] == 1) {

                       inWords[j] = '';

                   }

                   else {

                       inWords[j] = iWords[actnumber[i]];

                   }
                   if (actnumber[i + 1] != 0 || actnumber[i] > 0) {
                       inWords[j] = inWords[j] + " Lakh";

                   }

                   break;

               case 6:

                   tens_complication();

                   break;

               case 7:

                   if (actnumber[i] == 0 || actnumber[i + 1] == 1) {

                       inWords[j] = '';

                   }

                   else {

                       inWords[j] = iWords[actnumber[i]];

                   }

                   inWords[j] = inWords[j] + " Crore";

                   break;

               case 8:

                   tens_complication();

                   break;

               default:

                   break;

           }

           j++;

       }



       function tens_complication() {

           if (actnumber[i] == 0) {

               inWords[j] = '';

           }

           else if (actnumber[i] == 1) {

               inWords[j] = ePlace[actnumber[i - 1]];

           }

           else {

               inWords[j] = tensPlace[actnumber[i]];

           }

       }

       inWords.reverse();

       for (i = 0; i < inWords.length; i++) {

           finalWord += inWords[i];

       }

       return finalWord;

   } 
