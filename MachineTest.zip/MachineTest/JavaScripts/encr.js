function ascii_value (c)
{
        // restrict input to a single character
        c = c . charAt (0);
        
        // loop through all possible ASCII values
        var i;
        for (i = 0; i < 256; ++ i)
        {
                // convert i into a 2-digit hex string
                var h = i . toString (16);
                if (h . length == 1)
                        h = "0" + h;
                        
                // insert a % character into the string
                h = "%" + h;
                
                // determine the character represented by the escape code
                h = unescape (h);
                
                // if the characters match, we've found the ASCII value
                if (h == c)
                        break;
        }
		
        return i;
}
function stringToAsciinew (someString,dtstamp){

   var arry = someString.split("");
   var d1
    for(var i in arry){
    d1=""
    // alert(dtstamp);
    d1=arry[i].charCodeAt(0)
    //alert(d1+"=d1")
        arry[i] = parseInt(d1) + parseFloat(dtstamp);
       
      // alert("prefn"+arry[i] ); 
    }
    return arry;
}
function stringToAsciiold (someString){
//debugger;
    var str="" + someString
   var arry = str.split("");
   var d1
    for(var i in arry){
    d1=""
    // alert(dtstamp);
    d1=arry[i].charCodeAt(0)
    //alert(d1+"=d1")
        arry[i] = parseInt(d1) + parseInt(2);
       
      // alert("prefn"+arry[i] ); 
    }
    return arry;
}
function asciiToStringnew (asciiArray,dtstamp){

    var str = "";
    var len = asciiArray.length;
    for(var i=0; i<len; i++){
        str += String.fromCharCode(asciiArray[i]-parseInt(dtstamp));

    }
    return str;
}

function asciiToString (asciiArray){
    var str = "";
    var len = asciiArray.length;
    for(var i=0; i<len; i++){
        str += String.fromCharCode(asciiArray[i]-2);
    }
    return str;
}
function crstamp(tempTim,tempDt)
{
   var stp ="";
   var dat = tempDt.value.split(",");
   var tday=dat[0]
    if (tday < 10)
    tday = "0" + tday
    
   var tmon=dat[1]
   if (tmon < 10)
    tmon = "0" + tmon
    
   var tyr=dat[2]
   tyr=Right(tyr,2)
   var tim = tempTim.value.split(":");
   var hours = tim[0]
   if (hours < 10)
    hours = "0" + hours
    var minutes = tim[1]

  if (minutes < 10)
   minutes = "0" + minutes
   stp =tday+tmon+tyr+hours+minutes
   
   return stp;
}
function crstamp1(tempTim)
{
    
  /* var dat = document.form1.Dt.value.split(",");
   var tday=dat[0]
    if (tday < 10)
    tday = "0" + tday
    
   var tmon=dat[1]
   if (tmon < 10)
    tmon = "0" + tmon
    
   var tyr=dat[2]
   tyr=Right(tyr,2)
   */
    var tim = tempTim.value.split(":"); //mdocument.getElementById('Tm').value.split(":");
   var hours = tim[0]
   if (hours < 10)
    hours = "0" + hours
    var minutes = tim[1]

  if (minutes < 10)
   minutes = "0" + minutes
   
   //stp =tday+tmon+tyr+hours+minutes
   var stp   =parseInt(hours)+parseInt(minutes);
   
    
   return stp;
}
function getaQuote()
{
var rnr=Math.floor(Math.random()*101)

return  rnr;
}
function Right(str, n)
        /***
                IN: str - the string we are RIGHTing
                    n - the number of characters we want to return

                RETVAL: n characters from the right side of the string
        ***/
        {
                if (n <= 0)     // Invalid bound, return blank string
                   return "";
                else if (n > String(str).length)   // Invalid bound, return
                   return str;                     // entire string
                else { // Valid bound, return appropriate substring
                   var iLen = String(str).length;
                   return String(str).substring(iLen, iLen - n);
                }
        }


/*function smform()
{
     document.form1.action= "Login/loginverifyad.asp"
     //document.form1.action= "index9.asp?submit = 'Login' "
	 document.form1.submit();
}*/

//var myString = "xyz";
//var myAsciiArray = stringToAscii(myString);
//alert(myAsciiArray);
//var myAsciiToString = asciiToString(myAsciiArray);
//alert(myAsciiToString);