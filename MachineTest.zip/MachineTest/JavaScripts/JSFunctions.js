//Function to check maxlength of multiline textboxes
function CheckLength(control, desc, length)
    {
        var Ctrl = document.getElementById('ctl00_ContentPlaceHolder1_' + control);
        //alert(Ctrl);
        var temp;                          
        if (Ctrl.value.length > length) 
            {
                //alert("Length : " + length); 
                temp = Ctrl.value.substring(0, length);                               
                Ctrl.value = "";	
                Ctrl.focus();	
                Ctrl.select();		                 
                Ctrl.value = temp;        
                alert(desc +" maximum length must be " + length + " characters !");
            }
    }

//Function to check maxlength of multiline textboxes
function CheckLengthWithoutMasterPage(control, desc, length)
    {
        var Ctrl = document.getElementById(control);
        //alert(Ctrl);
        var temp;                          
        if (Ctrl.value.length > length) 
            {
                //alert("Length : " + length); 
                temp = Ctrl.value.substring(0, length);                               
                Ctrl.value = "";	
                Ctrl.focus();	
                Ctrl.select();		                 
                Ctrl.value = temp;        
                alert(desc +" maximum length must be " + length + " characters !");
            }
    }

    function CallDoCal(id) {
        
        var index = id.indexOf("_")

        var parent = id.substring(0, index - 1)

        var unique = id.substring((index - 1), index)

        // textDate because the id of the textbox is 'txtdate'

        var f = parent + unique // +"_txtDate"

        //var f="_txtDate"

        var a1 = new Array();

        a1 = id.split("_");

        var c = a1[0] + "_" + a1[1] + "_" + a1[2] + "_txtdate";
       // alert(c);
        var x = document.getElementById(c)
       // alert(x);
        DoCal(x,c)

        //document.getElementById("txtWarrantyDetails").getAttribute("value")=123

        //id1="abc";

        //alert(index);

        //alert(parent);

        //alert(unique);

        //alert(f);

        //alert(x);

        //alert(id);

        //alert(id+" "+txtWarrantyDetails);

        //document.WarrantyExpiryDate_txtDate.value="123";

        //document.getElementById("CommDate_txtDate").getAttribute("value")="lll"

    }

    function DoCal(elTarget,id) {
        
        //        if (showModalDialog) {
        //            var sRtn;
        //            sRtn = showModalDialog("Calendar.aspx", null, "center=yes;dialogWidth=170pt;dialogHeight=155pt;status:no;help:no;edge:sunken");
        window.open('Calendar.aspx?ControlID=' + id, window.name + '_0', 'width=500,height=555,toolbar=false,resizable=0');
        return false;
        //alert("My Date = " + sRtn);
        //            if (sRtn != "" && sRtn != "undefined")
        //                elTarget.value = ChangeFormat(sRtn);
        //            else if (sRtn == "undefined")
        //                elTarget.value = "";
        //        } else
        //            alert("Internet Explorer 4.0 or later is required.")
    }

    function ChangeFormat(datefield) {

        var s = datefield;

        var j = s.split("/");

        var dd = Number(j[0]);

        var mm = Number(j[1]);

        var yy = Number(j[2]);

        var mystr;

        if (dd < 10 && mm < 10)

            mystr = "0" + dd + "/0" + mm + "/" + yy;

        else if (mm < 10)

            mystr = dd + "/0" + mm + "/" + yy;

        else if (dd < 10)

        /*mystr = "0" + dd + "/0" + mm + "/" + yy; */

        /* New Modifed Code Below*/

            mystr = "0" + dd + "/" + mm + "/" + yy;

        else

            mystr = s;

        return mystr;

    }
