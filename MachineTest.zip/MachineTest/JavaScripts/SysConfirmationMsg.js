
window.onload = function() {

    setToDefault();
}
    


function setToDefault() {
    var agree = confirm("This system may be accessed and used only for authorized activities by authorized personnel. All information in this system is the property of Ratnakar Bank Ltd. Any unauthorized access or attempt to access will be considered as a violation and will attract penal action. The system is being monitored to ensure compliance with Ratnakar Bank Ltd. policies.");

    if (agree) {

        document.getElementById('txtUserId').focus();
        return true;
    }
    else {
        window.opener = 'x';
        window.close();

    }

}
        