(function($){
  $.fn.make_favorite = function(){

    var callback = function(response){
      console.log(response);
    };

    return this.each(function(){

      $(this).click(function(){
        var params = {
          item_type:  $(this).attr('href').match(/\w+/)[0],  // 'article'
          item_id:    $(this).attr('href').match(/\d+/)[0]   // 15
        };

        $.post('/htmlpage.htm', params, callback, 'json');

        // stop event propagation
        return false;
      });
    });
  };
})(jQuery);