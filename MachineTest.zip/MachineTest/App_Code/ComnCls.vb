﻿Imports Microsoft.VisualBasic
Imports System
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Namespace SQLDataAccessLayer.DAL
    Public Class BaseLayer
        Implements IError
#Region " Variables "

        Public cmd As IDbCommand = New SqlCommand()
        Public strConnectionString As String = ""
        Dim cnn As New SqlConnection()
        Dim cnnHRIS As New SqlConnection()

        Public handleErrors As Boolean = False
        Public strLastError As String = ""

        Protected Const Null_cmd As String = "Null Command Object Cought."

        Public Uid As String '= HttpContext.Current.Session("UserID")
        Public sMode As String = HttpContext.Current.Request("Mode")
        Protected Const Null_cmd_msg As String = "Invalid Sql-Statement OR Command Paramater."

#End Region

#Region "GET CONNECTION"
        Public Function GetConnection() As SqlConnection
            Dim objConnectionStringSettings As ConnectionStringSettings = ConfigurationManager.ConnectionStrings("ConString")
            strConnectionString = objConnectionStringSettings.ConnectionString
            cnn.ConnectionString = strConnectionString
            Return cnn
        End Function
#End Region

        Public Sub New()
            Dim objConnectionStringSettings As ConnectionStringSettings = ConfigurationManager.ConnectionStrings("ConString")
            Try
                strConnectionString = objConnectionStringSettings.ConnectionString
                cnn.ConnectionString = strConnectionString
                cmd.Connection = cnn
            Catch ex As Exception

            End Try
        End Sub

        Private Sub Open()
            Try
                cmd.Connection.Open()
            Catch ex As Exception

            End Try
        End Sub

        Private Sub Close()
            SqlConnection.ClearPool(cnn)
            cmd.Connection.Close()
            cmd.Dispose()
            cnn.Close()
            cnn.Dispose()
        End Sub

        Public Function CreateExecuteReader() As IDataReader
            Dim reader As IDataReader = Nothing
            Try
                Me.Open()
                reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            Catch ex As SqlClient.SqlException

            Catch ex As Exception

            End Try
            Return reader
        End Function

        Public Function CreateExecuteScalar() As Object
            Dim obj As Object = Nothing
            Try
                Me.Open()
                obj = cmd.ExecuteScalar()
                Me.Close()
            Catch ex As SqlClient.SqlException

            Catch ex As Exception

            End Try
            Return obj
        End Function

        Public Function CreateExecuteNonQuery() As Integer
            Dim i As Integer = -1
            Try
                Me.Open()
                i = cmd.ExecuteNonQuery()
                Me.Close()
            Catch ex As Exception

            End Try
            Return i
        End Function

        Public Function CreateExecuteDataSet() As DataSet
            Dim da As SqlDataAdapter = Nothing
            Dim ds As DataSet = Nothing
            Try
                da = New SqlDataAdapter()
                da.SelectCommand = CType(cmd, SqlCommand)
                da.SelectCommand.CommandTimeout = 100080
                ds = New DataSet()
                da.Fill(ds)
            Catch ex As SqlClient.SqlException

            Catch ex As Exception

            Finally
                da.Dispose()
                ds.Dispose()
                Dispose()
                'If cnn.State = ConnectionState.Open Then
                '    cnn.Close()
                'End If
            End Try
            Return ds
        End Function

        Public Sub Dispose()
            SqlConnection.ClearPool(cnn)
            cmd.Connection.Close()
            cmd.Dispose()
            cnn.Close()
            cnn.Dispose()
        End Sub

#Region " Implementing Interface IERROR "
        'Implemented the event from the interface IERROR
        Public Event OnExecuteError(ByVal Reason As String, ByVal Message As String, ByVal Location As String) Implements IError.OnExecuteError
        'This function is used to raise the event
        Protected Sub ErrorOccured(ByVal Reason As String, ByVal Message As String, ByVal Location As String)
            'Transactions.BusinessLogic.ErrorLog.HandleError(Reason, Message, Location, Transactions.BusinessLogic.ErrorLog.ErrorType.Critical)
            RaiseEvent OnExecuteError(Reason, Message, Location)
        End Sub
#End Region
    End Class
 

#Region " DBACCESS CLASS LAYER "

    Public Class ComnCls
        Inherits BaseLayer

        Public Function ExecuteReader(Optional ByVal sQuery As String = vbNullString, Optional ByVal sProcedure As String = vbNullString) As IDataReader
            Dim reader As IDataReader = Nothing
            Try
                If Not sQuery Is Nothing Then
                    cmd.CommandText = sQuery
                ElseIf Not sProcedure Is Nothing Then
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = sProcedure
                Else
                    Return reader
                    Exit Function
                End If
                reader = Me.CreateExecuteReader()
            Catch ex As Exception
                
            End Try
            Return reader
        End Function

        Public Function ExecuteScalar(Optional ByVal sQuery As String = vbNullString, Optional ByVal sProcedure As String = vbNullString) As Object
            Dim obj As Object = Nothing
            Try
                If Not sQuery Is Nothing Then
                    cmd.CommandText = sQuery
                ElseIf Not sProcedure Is Nothing Then
                    cmd.CommandText = sProcedure
                    cmd.CommandType = CommandType.StoredProcedure
                Else
                    Return obj
                    Exit Function
                End If
                obj = Me.CreateExecuteScalar()
            Catch ex As Exception
               
            End Try
            Return obj
        End Function

        Public Function ExecuteSql(ByVal arrPrams As List(Of SqlParam), ByVal strArr As List(Of String)) As Integer
            Dim iResult As Integer = 0
            Dim IsSuccess As Boolean = False
            Dim txn As SqlTransaction = Nothing
            Try
                If arrPrams.Count > 0 Then
                    If (cmd.Connection.State = ConnectionState.Closed) Then cmd.Connection.Open()
                    txn = cmd.Connection.BeginTransaction()
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = txn
                    For i As Integer = 0 To arrPrams.Count - 1
                        cmd.CommandText = strArr(i).ToString()
                        If arrPrams(i) IsNot Nothing Then
                            cmd.Parameters.Clear()
                            For Each param As SqlParameter In arrPrams(i).sqlParm
                                cmd.Parameters.Add(param)
                            Next
                        End If
                        iResult = cmd.ExecuteNonQuery()
                        If (iResult = 0) Then
                            IsSuccess = False
                        Else
                            IsSuccess = True
                        End If

                        If IsSuccess = False Then
                            Throw New Exception("Transaction Failed" & strArr(i).ToString())
                        End If
                    Next
                    txn.Commit()
                End If
            Catch ex As Exception
                txn.Rollback()
                IsSuccess = False

            Finally
                Dispose()
            End Try
            Return iResult
        End Function

        Public Function ExecSpInsert(ByVal strSpName As String, ByVal intInputParamNo As Integer, ByVal objInputArr() As Object, Optional ByRef objOutPutArr As Object = "Temp", Optional ByVal intNoOfOut As Integer = 0) As Boolean
            Dim intcount As Integer
            Dim SqlAdap As New SqlDataAdapter
            Dim SqlCommandBuilder As New SqlCommandBuilder
            Try
                If cmd.Connection.State = ConnectionState.Closed Then cmd.Connection.Open()
                cmd.CommandText = strSpName
                cmd.CommandType = CommandType.StoredProcedure
                SqlAdap.InsertCommand = cmd
                SqlCommandBuilder.DeriveParameters(SqlAdap.InsertCommand)
                For intcount = 1 To intInputParamNo
                    SqlAdap.InsertCommand.Parameters(intcount).Value = objInputArr(intcount - 1)
                Next
                Dim intOut As Integer
                intOut = intcount
                For intcount = intOut To intcount + intNoOfOut - 1
                    SqlAdap.InsertCommand.Parameters(intcount).Direction = ParameterDirection.Output
                Next
                SqlAdap.InsertCommand.ExecuteNonQuery()
                Dim intRowCount As Integer
                intOut = intcount - 1
                For intcount = intInputParamNo + 1 To intInputParamNo + intNoOfOut
                    objOutPutArr(intRowCount) = SqlAdap.InsertCommand.Parameters(intcount).Value
                    intRowCount = intRowCount + 1
                Next
                SqlAdap.InsertCommand.Parameters.Clear()
                cmd.Connection.Close()
                Return True
            Catch ex As Exception
                cmd.Connection.Close()
                CType(cmd.Connection, IDisposable).Dispose()
                '  Throw ex

                Return False
            End Try
        End Function

        Public Function ExecuteNonQuery(Optional ByVal sQuery As String = vbNullString, Optional ByVal sProcedure As String = vbNullString) As Integer
            Dim i As Integer = -1
            Try
                If Not sQuery Is Nothing Then
                    cmd.CommandText = sQuery
                ElseIf Not sProcedure Is Nothing Then
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = sProcedure
                Else
                    Return i
                    Exit Function
                End If
                i = Me.CreateExecuteNonQuery()
            Catch ex As SqlClient.SqlException

            Catch ex As Exception

            End Try
            Return i
        End Function

        Public Function ExecuteDataSet(Optional ByVal sQuery As String = vbNullString, Optional ByVal sProcedure As String = vbNullString) As DataSet
            Dim ds As DataSet = Nothing
            Try
                If Not sQuery Is Nothing Then
                    cmd.CommandText = sQuery
                ElseIf Not sProcedure Is Nothing Then
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.CommandText = sProcedure
                Else
                    Return ds
                    Exit Function
                End If
                ds = Me.CreateExecuteDataSet()
            Catch ex As Exception
 
            End Try
            Return ds
        End Function

        Public Sub AddParameter(ByVal paramname As String, ByVal paramvalue As Object)
            Dim param As SqlParameter = New SqlParameter(paramname, paramvalue)
            cmd.Parameters.Add(param)
        End Sub

        Public Sub AddParameter(ByVal param As IDataParameter)
            cmd.Parameters.Add(param)
        End Sub

#Region "ADD TRANS PARAMETER."
        Public Sub AddTransParameter(ByVal SQLCmd As SqlCommand, ByVal paramname As String, ByVal paramvalue As Object)
            Dim param As SqlParameter = New SqlParameter(paramname, paramvalue)
            SQLCmd.Parameters.Add(param)
        End Sub
#End Region

#Region "TRANS EXECUTE SCALAR."
        Public Function TransExecuteScalar(ByVal SQLCmd As SqlCommand, Optional ByVal sQuery As String = vbNullString, Optional ByVal sProcedure As String = vbNullString) As Object
            Dim obj As Object = Nothing
            Try
                If Not sQuery Is Nothing Then
                    SQLCmd.CommandText = sQuery
                ElseIf Not sProcedure Is Nothing Then
                    SQLCmd.CommandType = CommandType.StoredProcedure
                    SQLCmd.CommandText = sProcedure
                Else
                    ErrorOccured("Error : ", Null_cmd_msg, "Error Occured in ExecuteScalar...!")
                    Return obj
                    Exit Function
                End If
                obj = Me.CreateTransExecuteScalar(SQLCmd)
            Catch ex As Exception

            End Try
            Return obj
        End Function
#End Region

#Region "CREATE TRANS EXECUTE SCALAR"

        Public Function CreateTransExecuteScalar(ByVal SQLCmd As SqlCommand) As Object
            Dim obj As Object = Nothing
            Try
                obj = SQLCmd.ExecuteScalar()
            Catch ex As SqlClient.SqlException

            Catch ex As Exception

            End Try
            Return obj
        End Function
#End Region

#Region "TRANS EXECUTE NON QUERY."
        Public Function TransExecuteNonQuery(ByVal SQLCmd As SqlCommand, Optional ByVal sQuery As String = vbNullString, Optional ByVal sProcedure As String = vbNullString) As Integer
            Dim i As Integer = -1
            Try
                If Not sQuery Is Nothing Then
                    SQLCmd.CommandText = sQuery
                ElseIf Not sProcedure Is Nothing Then
                    SQLCmd.CommandType = CommandType.StoredProcedure
                    SQLCmd.CommandText = sProcedure
                Else
                    ErrorOccured("Error : ", Null_cmd_msg, "Error Occured in TransExecuteNonQuery !")
                    Return i
                    Exit Function
                End If
                i = Me.CreateTransExecuteNonQuery(SQLCmd)
            Catch ex As SqlClient.SqlException

            Catch ex As Exception

            End Try
            Return i
        End Function

        Public Function TransExecuteDataSet(ByVal SQLCmd As SqlCommand, Optional ByVal sQuery As String = vbNullString, Optional ByVal sProcedure As String = vbNullString) As DataSet
            Dim ds As DataSet = Nothing
            Try
                If Not sQuery Is Nothing Then
                    SQLCmd.CommandText = sQuery
                ElseIf Not sProcedure Is Nothing Then
                    SQLCmd.CommandType = CommandType.StoredProcedure
                    SQLCmd.CommandText = sProcedure
                    SQLCmd.CommandTimeout = 2000
                Else
                    Return ds
                    Exit Function
                End If
                ds = Me.CreateTransExecuteDataSet(SQLCmd)
            Catch ex As Exception

            End Try
            Return ds
        End Function

        Public Function CreateTransExecuteDataSet(ByVal SQLCmd As SqlCommand) As DataSet
            Dim da As SqlDataAdapter = Nothing
            Dim ds As DataSet = Nothing
            Try
                da = New SqlDataAdapter()
                da.SelectCommand = CType(SQLCmd, SqlCommand)
                ds = New DataSet()
                da.Fill(ds)
            Catch ex As SqlClient.SqlException

            Catch ex As Exception

            Finally
                da.Dispose()
                ds.Dispose()
            End Try
            Return ds
        End Function
#End Region

#Region "CREATE TRANS EXECUTE NON QUERY"

        Public Function CreateTransExecuteNonQuery(ByVal SQLCmd As SqlCommand) As Integer
            Dim i As Integer = -1
            Try
                i = SQLCmd.ExecuteNonQuery()
            Catch ex As SqlClient.SqlException

            Catch ex As Exception

            Finally
                Dispose()
            End Try
            Return i
        End Function
#End Region

    End Class

#End Region

#Region "SET SQLPARAMETER"

    Public Class SqlParam
        Private _sqlParm As SqlParameter()
        Public Property sqlParm() As SqlParameter()
            Get
                Return _sqlParm
            End Get
            Set(ByVal value As SqlParameter())
                _sqlParm = value
            End Set
        End Property
        Public Sub New(ByVal oParam As SqlParameter())
            _sqlParm = oParam
        End Sub
    End Class
#End Region

#Region " DATA COMMUNICATION CLASS LAYER "

    Public Class DataCommunicator
        Inherits ComnCls

        Public Property ConnectionString() As String
            Get
                Return strConnectionString
            End Get
            Set(ByVal value As String)
                strConnectionString = value
            End Set
        End Property

        Public Property CommandText() As String
            Get
                Return cmd.CommandText
            End Get
            Set(ByVal value As String)
                cmd.CommandText = value
                cmd.Parameters.Clear()
            End Set
        End Property

        Public ReadOnly Property Parameters() As IDataParameterCollection
            Get
                Return cmd.Parameters
            End Get
        End Property

        Public Property HandleExceptions() As Boolean
            Get
                Return handleErrors
            End Get
            Set(ByVal value As Boolean)
                handleErrors = value
            End Set
        End Property

        Public ReadOnly Property LastError() As String
            Get
                Return strLastError
            End Get
        End Property
    End Class


#End Region

#Region " IERROR INTERFACE "
    Public Interface IError
        Event OnExecuteError(ByVal Reason As String, ByVal Message As String, ByVal Location As String)
    End Interface

#End Region



End Namespace
